<?php
class template
{
	function headerfun()
	{		
	return array(
	"Home"=>"index.php",
	"Bestsellers"=>"index.php",
	"Magazines"=>"index.php",					 	"Bargain"=>"index.php",
	"New Releases"=>"index.php",
	"E-Books"=>"index.php",
	"Contact"=>"index.php");
	}
	
	
		
	public function footerfun()
	{		
	return array(
	"Home"=>"index.html",
	"Bestsellers"=>"index.php",
	"Magazines"=>"index.php",					 	"Bargain"=>"index.php",
	"New Releases"=>"index.php",
	"E-Books"=>"index.php",
	"Contact"=>"index.php");
	}
	
}


?>