<?php 
/********Product class**************/

class Product{
	
	private $pid;//modification for editProduct page
	private $pName;		
	private $image;	
	private $price;
	private $year;
	private $copies;
	private $description;	
	private $cid;

	public function __construct(){
		$this->pid="";
		$this->pname="";		
		$this->image="";
		$this->price="";
	
		$this->year="";
		$this->copies="";
		$this->description="";	
		$this->cid="";		
	}	
	
	public function setPID($p_id){
		$this->pid=$p_id;
	}
	
	public function getPID(){
	 return $this->pid;	
	}
	
	public function setpName($p_Name){
		$this->pname=$p_Name;	
	}
	
	public function getpName(){
		return $this->pname;
	}
	
		
	public function setpImage($p_Img)	{
		$this->image=$p_Img;	
	}

	public function getpImage(){
 		return $this->image;	
	}
	
	
	public function setpPrice($p_Price){
		$this->price=$p_Price;	
	}
	
	public function getpPrice(){
		return $this->price;	
	}	
	
	
	public function setpYear($p_Year){
		$this->year=$p_Year;	
	}
	
	public function getpYear(){
		return $this->year;	
	}	
	
	
	public function setpCopies($p_Copies){
		$this->copies=$p_Copies;	
	}
	
	public function getpCopies(){
		return $this->copies;	
	}	
	
	
	public function setpDesc($p_Desc){
		$this->description=$p_Desc;	
	}
	
	public function getpDesc(){
		return $this->description;	
	}
	
	public function setCID($cat_id){
		$this->cid=$cat_id;	
	}
	
	public function getCID(){
		return $this->cid;	
	}

}
?>