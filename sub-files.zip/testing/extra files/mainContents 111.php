<?php 
//require_once("db.php");
$whrstr="";
if ($_GET['cid']){
	$whrstr="WHERE cat_id =".$_GET['cid'];
}
else{
	$whrstr="";
}
$sql = "Select * from books ".$whrstr;
echo $sql;
$rs = mysql_query($sql);
$dataArray = array();
while($row = mysql_fetch_row($rs)){
	array_push($dataArray,$row);
}
//print_r($dataArray);
?>                
                <table cellpadding="0" cellspacing="0" border="0px" align="left">
                
               <?php for($i = 0; $i<count($dataArray) ; $i++){ ?>
                <form name="form[i]" method="post" action="addToCart.php" >
                <input name="id" type="hidden" value="<?php echo $dataArray[i][0];  ?>" />
                <input name="name" type="hidden" value="<?php echo $dataArray[i][1];  ?>" />
                <input name="image" type="hidden" value="<?php echo $dataArray[i][2];  ?>" />
                 <input name="price" type="hidden" value="<?php echo $dataArray[i][3];  ?>" />
                 <input name="year" type="hidden" value="<?php echo $dataArray[i][4];  ?>" />
                 <input name="copies" type="hidden" value="<?php echo $dataArray[i][5];  ?>" />
                <input name="desc" type="hidden" value="<?php echo $dataArray[i][7];  ?>" />               
                             
                <tr>
                <td><img src="Products/<?php echo $dataArray[$i][2];  ?>" height="100px" width="100px" /></td>
                
                <td valign="top">
                    <table cellpadding="0" cellspacing="0" border="0px" align="left">
                    <tr>
                      <td align="left">&nbsp;</td>
                      <td align="left">Name</td><td align="left"><?php echo $dataArray[$i][1];?></td></tr>
                    <tr>
                      <td align="left">&nbsp;</td>
                      <td align="left">Price</td><td align="left"><?php echo $dataArray[$i][3];?></td></tr>
                      <tr>
                      <td align="left">&nbsp;</td>
                      <td align="left">Pub Year</td><td align="left"><?php echo $dataArray[$i][4];?></td></tr>
                    
                    <tr>
                      <td align="left">&nbsp;</td>
                     <td align="left">Copies</td><td align="left"><?php echo $dataArray[$i][5];?></td></tr>                                            
                    <tr>
                      <td align="left" valign="top">&nbsp;</td>
                      <td align="left" valign="top">Description</td><td align="left"><?php echo substr($dataArray[$i][7],0,200);?>......</td></tr>
                      
                                        
                    <tr><td colspan="3" align="left"><input type="submit" name="sub" value="Add to cart" /></td></tr>
                    </table>
                </td>                            
                </tr>
                </form>               
                 <?php }
				?> 
               
</table>                
                