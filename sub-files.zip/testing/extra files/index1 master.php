<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<title>Free Website Templates</title>
<link href="style/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="page_header">
	<div id="page_title">
	<h1>
	<img src="images/header_logo.gif" width="25" height="26" alt="" />
	<span>Books Forever</span>
	</h1>
	</div>
    
	<div id="header_search">
		<form method="post" action="http://www.freewebsitetemplates.com">
		<div>
		<h3><span>Find:</span></h3>  
		<input type="text" />
		<input type="image" src="images/search_button.gif" class="submit" />
       <a href="admin/index.php" > <img src="images/admin button.gif" height="25" align="right" /> </a>
       
		</div>
        
	  </form>
	</div>
 
</div>
<!--  <a href="admin/index.php" > <img src="images/admin button.gif" /> </a>-->
<div id="menucontainer">
<div id="menunav">
<?php require("include/header.php");?>
	
</div>
</div>

 <div id="page_wrapper">
	<!-- BEGIN :: LEFT SIDEBAR -->
    
    <div id="page_leftcol">
		
      <?php require("leftcontents.php");?>  
  </div>
	</div>
	<!-- //END :: LEFT SIDEBAR -->
    
    
	<!-- BEGIN :: MAIN COL -->
	<div id="page_maincol">
		<div id="maincol_top">
			<div class="sideimg">&nbsp;</div>
			<div class="content">
				<h2><span>Welcome to our site</span></h2>
				<p>
This is a template designed by free website templates for you for free you can replace all the text by your own text. This is just a place holder so you can see how the site would look like. If you're having problems editing the template please don't hesitate to ask for help on the forum. You will get help
				</p>
				<div class="readmore"><a href="http://www.freewebsitetemplates.com">Read More</a></div>
			</div>
		</div>
		<div class="borderbox">
		<div class="maincol_box">
		<div id="bestsellers">
			<h2><span>Top Bestsellers</span></h2>
			<!-- BEGIN BOOK REVIEW ONE -->
			<div class="content">
			<div class="wrapper">
				<div class="bookcover">
                
<img src="images/book01.jpg" width="65" height="100" alt="Book Cover" />
    
    
            </div>
				<p>
Steffy, a business columnist for the Houston Chronicle,first began covering British Petroleum in 2005 after the deadly explosion at their Texas City refinery.
				</p>
				<p>
His investigations reveal a corporate culture of cost-cutting initiatives that put profits ahead of workers lives
				</p>
				<div class="info">
					<div class="price">
					<h3>Price: $20.00</h3>
					</div>
					<div class="buynow">
					<a href="http://www.freewebsitetemplates.com">Buy Now</a>
					</div>
					<div class="clearthis">.</div>
				</div>
			</div>
			</div>
			<!-- //END BOOK REVIEW ONE -->
			<!-- BEGIN BOOK REVIEW TWO -->
			<div class="content">
			<div class="wrapper">
				<div class="bookcover">

<img src="images/book02.jpg" width="65" height="100" alt="Book Cover" />
                </div>
				<p>
Many people feel orphaned in their lives; however, there is a vast difference between feeling like an orphan and being orphaned.
				</p>
				<p>
Orphaned children do less well in school however, studies show that a mere 15 minutes a day of individualized caring attention.. 
				</p>
				<div class="info">
					<div class="price">
					<h3>Price: $20.00</h3>
					</div>
					<div class="buynow">
					<a href="http://www.freewebsitetemplates.com">Buy Now</a>
					</div>
					<div class="clearthis">.</div>
				</div>
			</div>
			</div>
			<!-- //END BOOK REVIEW TWO -->
			<!-- BEGIN BOOK REVIEW THREE -->
			<div class="content">
			<div class="wrapper">
				<div class="bookcover">


<img src="images/book03.jpg" width="65" height="100" alt="Book Cover" />
                </div>
				<p>
A thrilling adventure story about a Canadian family in Vientiane, Laos when the communists take over in 1975.  
				</p>
				<p>
With their American friend gone. But before they know it they are involved in a breathtaking and dangerous mission to save a Lao family
				</p>
				<div class="info">
					<div class="price">
					<h3>Price: $20.00</h3>
					</div>
					<div class="buynow">
					<a href="http://www.freewebsitetemplates.com">Buy Now</a>
					</div>
					<div class="clearthis">.</div>
				</div>
			</div>
			</div>
			<!-- //END BOOK REVIEW THREE -->
			<!-- BEGIN BOOK REVIEW FOUR -->
			<div class="content">
			<div class="wrapper">
				<div class="bookcover">
                
               <img src="images/book04.gif" width="65" height="100" alt="Book Cover" />
                </div>
				<p>
The Sixth Man is basically a biography,a business man who struglle throughout his life for success... 
 				</p>
				<p>
This is just a model so you can see how the site would look like. If you're having problems about anything,ask for help on the my email.
				</p>
				<div class="info">
					<div class="price">
					<h3>Price: $20.00</h3>
					</div>
					<div class="buynow">
					<a href="http://www.freewebsitetemplates.com">Buy Now</a>
					</div>
					<div class="clearthis">.</div>
				</div>
				<div class="clearthis">.</div>
			</div>
			</div>
			<!-- //END BOOK REVIEW FOUR -->
			<div class="clearthis">.</div>
		</div>
		</div>
		</div>
		<div class="clearthis">.</div>
	</div>
	<!-- //END :: MAIN COL -->
	<!-- BEGIN :: RIGHT SIDEBAR -->
	<div id="page_rightcol">
		<div class="borderbox">
		<div class="rightcol_box">
		<div id="latest">
			<h2><span>Latest Releases &amp; News</span></h2>
			<div class="wrapper">
				<h3>June 22nd, 2005</h3>
				<div class="thumbnail"><img src="images/news_image01.gif" width="67" height="81" alt="News" /></div>
				<p>
This is a template designed by free website templates for you for free you can replace all the text by your own text. 
				</p>
				<p>
This is just a place holder so you can see how the site would look like. If you're having problems editing the template please don't hesitate to ask for help on the forum. You will get help
				</p>
				<h3>June 22nd, 2005</h3>
				<p>
This is just a place holder so you can see how the site would look like. If you're having problems editing the template please don't hesitate to ask for help on the forum. You will get help
				</p>
				<h3>June 26th, 2005</h3>
				<p>
This is a template designed by free website templates for you for free you can replace all the text by your own text. This is just a place holder so you can see how the site would look like. 
				</p>
				<p>
If you're having problems editing the template please don't hesitate to ask for help on the forum. You will get help as soon as possible. You can also use the forum to tell us what you like or dislike and what you would like to see more. Your feedback is very important to us and we will do everything to fulfil your wishes.
				</p>
				<div class="readmore"><a href="http://www.freewebsitetemplates.com">Read More</a></div>
			</div>
		</div>
		</div>
		</div>
		<div class="clearthis">.</div>
	</div>
	<!-- //END :: RIGHT SIDEBAR -->
</div>
<div id="page_spacing">
<div id="page_footer">
		<div id="links">
<?php require("include/footer.php");?>
	</div>
</div>
</div>
<div id="page_credit">
<a href="http://www.freewebsitetemplates.com">Copyright information goes here</a>
</div>

</body>
</html>