<?php

try
{
error_reporting(~E_NOTICE);
 session_start();
 if(isset($_SESSION['username'])){	

 //Class object creation
 require_once("../classes/Product.php");
 require_once("../datastore.php");
 
 $prod = new Product;
 
 $error_msg = "";
 $dir = "../Products/";
 if($_POST['sub']){
   
   $pName = trim($_POST['pName']);
   $pDesc = trim($_POST['pDesc']);
   $pPrice = trim($_POST['pPrice']);
   
   $pYear = trim($_POST['pYear']);
   
   $pCopies = trim($_POST['pCopies']);
   
   $cat_id    = ($_POST['cid']);
   //Validation
   echo $cat_id;
   if((!$pName)||(!$pDesc)||(!$pPrice || !$pYear || !$pCopies)){
     $error_msg  = "&nbsp;All Fields are Mandatory.";
   }
      
   
   if(!$error_msg){
     //Calling setter function
	 $prod->setpName($pName);
	 $prod->setpDesc($pDesc);
	 $prod->setpPrice($pPrice);
	 $prod->setpYear($pYear);     $prod->setpCopies($pCopies);
	 $prod->setCID($cat_id);
	 
    if(is_uploaded_file($_FILES['pImg']['tmp_name'])){
	 		
			$filename = $_FILES['pImg']['name'];
			
			if(move_uploaded_file($_FILES['pImg']['tmp_name'],$dir.$filename)){
			 	$prod->setpImage($filename);
			}else{
				echo "File not uploaded";
				
			}
	 }else{
	 	$prod->setpImage("");
	 
	  }	  
	  
	  //Datbase insertion code here
	  $pname  = $prod->getpName();
	  $pdesc  = $prod->getpDesc();
	  $pprice = $prod->getpPrice();
	  
	    $pyear = $prod->getpYear();  
		
	$pcopies= $prod->getpCopies();
	  
	  
	  $pimg   = $prod->getpImage();
	  $cid    = $prod->getCID();
	  
	 $sql = "insert into books (cat_id,title,description,image,price,year,b_copies) values (\"$cid\",\"$pname\",\"$pdesc\",\"$pimg\",\"$pprice\",\"$pyear\",\"$pcopies\") ";
	 
	 echo  $sql;
	 if(mysql_query($sql)){
	 
	 	header("Location: viewProducts.php");
		exit;
		
	 
	 }else{
	 
	 echo "error  ";
	 }   
   } 
 } 
?>
<html>
<head>
<title>Administration Area</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
<script type="text/javascript">
function showCategory(str)
{	
document.form1.action="addProduct.php?cid="+str;
document.form1.submit();
}
</script>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
			<td class="logo">
				Administration Area</td>
		</tr>
		
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="180px" valign="top" id="leftnav"><?php include("leftmenu.php");?></td>
			        <td class="maincontent_bak" valign="top" align="center">
                    <form name="form1" action="addProduct.php" method="post" enctype="multipart/form-data">
                    <table class="text_color" align="center" width="80%" >
                  
                    <tr><td colspan="2" align="center"><h4>Add Books</h4></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    <tr><td colspan="2" align="center"><?php if($error_msg){?><div align="center" style="background-color:#CCCCCC; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $error_msg; }?></div></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    
                    <tr>
                      <td>Select Category</td>
                      <td><?php require("getCategoryList.php");?></td>
                    </tr>
                    <tr>
                    <td width="22%">Book Title</td>
                    
                    <td width="78%"><input type="text" name="pName" value="<?php echo $pName; ?>" /></td>
                    
                    </tr>
                    
                    
                    <tr>
                      <td valign="top">Book Description</td>
                      <td><textarea name="pDesc" cols="" rows="3" value="<?php echo $pDesc; ?>" ></textarea></td>
                    </tr>
                    <tr>
                      <td>Book Price</td>
                      <td><input type="text" name="pPrice" value="<?php echo $pPrice; ?>" /></td>
                    </tr>
                    <tr>
                    <td>Book image</td>
                    
                    <td><input type="file" name="pImg" /><input type="text" name="cid" value="<?php echo $_GET['cid']; ?>" /></td>
                    
                    </tr>
                    
                    
                    <tr>
                      <td>Publish Year</td>
                      <td><input type="text" name="pYear" value="<?php echo $pYear; ?>" /></td>
                    </tr>
                    
                    <tr>
                      <td>Book Copies</td>
                      <td><input type="text" name="pCopies" value="<?php echo $pCopies; ?>" /></td>
                    </tr>
                    
                    <tr>
                    <td>&nbsp;</td>
                    
                    <td><input type="submit" name="sub" class="button" value="Add Product" />&nbsp;<input type="button" name="sub" class="button" value="Back" onClick="window.location = 'viewProducts.php'" /></td>
                    
                    </tr>
                    
                    </table>
                    
                    </form>
                    
                    </td>
			    </tr>
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
</body>
</html>

<?php } 
else
{
header("Location: index.php");	
}
?>

<?php } catch(Exception $e)
{
	echo "There is a problem in opening this page.";
}?>