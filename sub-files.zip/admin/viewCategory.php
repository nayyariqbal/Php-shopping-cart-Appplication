<?php 
try
{
	
 error_reporting(~E_NOTICE);
 session_start();   
 if(isset($_SESSION['username'])){	

 //Class object creation
 require_once("../datastore.php");
 $error_msg = "";
 $catsql = "SELECT * FROM categories order by id asc";
$catres = mysql_query($catsql);
$numrows = mysql_num_rows($catres);
if($numrows == 0)
{
$error_msg= "&nbsp;No Categories Found";
}
else
?>
<html>
<head>
<title>Administration Area</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
		  <td class="logo"> Administration Area</td>
	  </tr>
		
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="193" valign="top" id="leftnav"><?php include("leftmenu.php");?></td>
			        <td class="maincontent_bak" width="861" align="center" valign="top">
                    
                    <table align="center" width="80%" >
                  
                    <tr><td colspan="4" align="center"><h4>View Categories</h4></td></tr>
                    <tr><td colspan="4" align="right"><!--<a href="addCategory.php">Add new Category</a>--></td></tr>
                    <tr><td colspan="4" align="center"><?php if($error_msg){?><div align="center" style="background-color:#CCCCCC; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $error_msg; }?></div></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>                    
                  <tr>
                    <th width="16%" align="left">S No</th>
                    <th width="22%" align="left">Name</th>
                    <th width="22%" align="left">Image</th>
                    <th width="29%">&nbsp;</th>
                    <th width="33%">&nbsp;</th>
                  </tr>                   
               <?php 
			   $j = 1;
			   while($catrow = mysql_fetch_assoc($catres))
				{
			    ?>    
                  <tr>
                    <td><?php echo $j; ?></td>
                    <td><?php echo $catrow['name']; ?></td>
                   " <td><?php echo "<img src=\"../category/".$catrow['image']."\" />"; ?></td> 
					
                    <td></td>
                    <td><?php //echo "<a href=addProduct.php?cid=".$catrow['id'].">add Products</a>"; ?></td>
                  </tr>                  
                  <?php $j++; } ?>                                    
		           </table>                    
                    </td>
			    </tr>               
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
</body>
</html>

<?php } 
else
{
header("Location: index.php");	
}
?>

<?php } catch(Exception $e)
{
	echo "There is a problem in opening this page.";
}?>