<?php 
try
{
 error_reporting(~E_NOTICE); 
  session_start();  
  if(isset($_SESSION['username'])){	


 //Class object creation
 require_once("../datastore.php");
  //Step 0 - include pagination class
 require_once("../classes/Pagination.php");
 
 /* Step 1 Assign Basic Variables ****/	
	$page_limit = 2;
	$total = 0;	
	$paging = "";
	$max_pages = 10;
	
//Step 2 get total records. 
 	$cntrs    = mysql_query("SELECT count(*) from books"); 
 	$totalrow = mysql_fetch_row($cntrs);	
 	$total  =  $totalrow[0];/*echo $total;*/

//Tell the page name 
 	$_pageurl = "viewProducts.php";

 //Step 3 Create class object	
	$paginate = new Paginate($page_limit, $total, $_pageurl, $max_pages);
	$paging = $paginate->displayTable();
	$page = $paginate->currentPage;
	$paginate->start = $paginate->start -1;
    
	
	
	$view_msg = "";
    if($flag==1)
			{
 				$view_msg = "Product deleted sucessfully!!!!";
 
			 }
 elseif($flag ==2)
 			{
   				 $view_msg = "Product edited sucessfully!!!!";
 
 			}
 /*$whrstr = "";
 if(isset($cid)){$whrstr="AND b.cat_id = $cid";}*/
 
 $prodsql = "SELECT a.id as cat_id,a.name as cat_name, b.isbn as prod_id, b.title as book_title, b.description as prod_desc,"
           ." b.price as prod_price, b.year as pub_year ,"." b.b_copies as book_copies ,b.image as prod_img"
		   ." FROM categories a INNER JOIN books b"
		   ." WHERE a.id = b.cat_id ". $whrstr ." LIMIT $paginate->start, $paginate->limit";
/*echo $prodsql;*/

 
$prodres = mysql_query($prodsql);
$numrows = mysql_num_rows($prodres); //echo $numrows;
if($numrows == 0)
{
$view_msg= "&nbsp;No Books Found";
}
else
?>
<html>
<head>
<title>Administration Area</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>

<!--AJAX -->

<script type="text/javascript">
function showCategory(str)
{
	
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
	 
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
		
    document.getElementById("my_selection").innerHTML=xmlhttp.responseText;
	
    }
  }
  
xmlhttp.open("GET","ajaxprocessing.php?cid="+str,true);
/*alert("hello");*/
xmlhttp.send();
}
</script>

</head>
<body>

	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
		  <td class="logo"> Administration Area</td></td>
	  </tr>
		
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="193" valign="top" id="leftnav"><?php include("leftmenu.php");?></td>
			        <td class="maincontent_bak" width="861" align="center" valign="top">
                    
                    <table align="center" width="100%" id="my_selection">
                  
                    <tr><td colspan="6" align="center"><h4>View Books</h4></td></tr>
                    <tr>
                      <td>Select Category</td>
                      <td><?php require("getCategoryList.php");?></td>
                    </tr>
                    <tr><td colspan="6" align="center"><?php if($view_msg){?><div align="center" style="background-color:#FC0; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $view_msg; }?></div></td></tr>
                    <tr><td colspan="6" align="center">
                   
                    </td></tr>                    
                  
                  <tr>
                    <th width="11%" align="left">Category</th>
                    <th width="11%" align="left">Book Image</th>
                    <th width="11%" align="left">Book Name</th>
                    <th width="11%" align="left">Book Price</th>
                    
                    <th width="11%" align="left">Publishing Year</th>       
                             <th width="11%" align="left">Book Copies</th>
                    <th width="11%" align="left">Book Desc</th>
                    <th width="12%" align="left">Actions</th>
                    </tr>
                   
               <?php 
			   $j = 1;
			   while($prodrow = mysql_fetch_array($prodres))
				{
			    ?>
              
                  <tr>                    
                    <td><?php echo $prodrow['cat_name']; ?></td>
                    <td><?php echo "<img src=\"../Products/".$prodrow['prod_img']."\">"; ?></td>
                    <td><?php echo $prodrow['book_title']; ?></td>
                    <td><?php echo "\$".$prodrow['prod_price']; ?></td>
                    
                    <td><?php echo $prodrow['pub_year']; ?></td>
              
              <td><?php echo $prodrow['book_copies']; ?></td>
              
                    <td><?php echo $prodrow['prod_desc'];?></td>
                    
                   <td><a href="editProduct.php?cid=<?php echo $prodrow['cat_id'];?>&pid=<?php echo $prodrow['prod_id'];?>"><img src="layout/edit_icon.jpg" width="30" height="38"></a> <a href="deleteProduct.php?pid=<?php echo $prodrow['prod_id']; ?>" onClick="return confirm('This action will delete this product?\n Are you sure to continue?');"><img src="layout/psd-delete-icon.jpg" width="31" height="36"></a></td>
                 
                  </tr>        
                  
                  <?php } ?>
                  <tr>
                    <td class="pagination" colspan="6" align="center" ><?php echo $paging; ?></td>
                    </tr>
                                    
		           </table>       
                    
                    </td>
			    </tr>
               
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
   
</body>
</html>

<?php } 
else
{
header("Location: index.php");	
}
?>

<?php } catch(Exception $e)
{
	echo "There is a problem in opening this page.";
}?>