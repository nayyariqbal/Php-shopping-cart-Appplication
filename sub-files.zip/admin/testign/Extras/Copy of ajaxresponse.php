<?php
error_reporting(~E_NOTICE);   
 //Class object creation
 require_once("../datastore.php");
 require_once("getCategoryList.php");
 
 $cid = $_GET['cid']; 
 
 $prodsql = "SELECT a.id as cat_id,a.name as cat_name, b.isbn as prod_id, b.title as book_title, b.description as prod_desc,"
           ." b.price as prod_price, b.year as pub_year ,"." b.b_copies as book_copies ,b.image as prod_img"
		   ." FROM categories a INNER JOIN books b" 
		   ." WHERE a.id = b.cat_id AND b.cat_id=$cid";
		   
$prodres = mysql_query($prodsql);
$numrow = mysql_num_rows($prodres); //echo $numrow;
echo "<table border=\"0\" width=\"700\">";

echo "<tr>";
echo "<th width='13%' align='left'>Category</th>";
echo "<th width='18%' align='left'>Book Image</th>";
echo "<th width='16%' align='left'>Book Name</th>";
echo "<th width='16%' align='left'>Book Price</th>";
echo "";
echo "<th width='11%' align='left'>Publishing Year</th>";
echo "<th width='11%' align='left'>Book Copies</th>";
echo "<th width='13%' align='left'>Book Desc</th>";
echo "<th width='24%' align='left'>Actions</th>";




echo "</tr>";

while($prodrow = mysql_fetch_array($prodres))
{
		
	echo $str = "<tr>
	<td>".$prodrow['cat_name'] ."</td>
	<td>"."<img src=\"../Products/".$prodrow['prod_img']."\">" ."</td>
	<td>".$prodrow['book_title'] ."</td>
	<td>".$prodrow['prod_price']."</td>
	<td>".$prodrow['pub_year']."</td>
	<td>".$prodrow['book_copies']."</td>
	<td>".$prodrow['prod_desc']."</td>
	
	
	
</tr>";


	/* print( '<a href="http://mylink.com/path/">Click Me</a>' ); */

/*echo '<a href="http://mylink.com/path/">Click Me</a>' ; */

/*echo "<a href=\"some_url\">click me</a>";*/
	}
echo "</table>";



?>