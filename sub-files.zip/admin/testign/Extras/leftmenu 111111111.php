<link rel="stylesheet" type="text/css" href="styles/admin.css" />
<script src="js/jquery-1.5.1.js"></script>  

<script>
$(document).ready(function(){

	//Hide (Collapse) the toggle containers on load
	$(".toggle_container").hide(); 

	//Switch the "Open" and "Close" state per click then slide up/down (depending on open/close state)
	$("h2.trigger").click(function(){
		
		$(this).toggleClass("active").next().slideToggle("slow");
		return false; 
		
		$(".toggle_container").slideToggle("slow");
   
	});

});
</script>


<?php  
error_reporting(~E_NOTICE);
session_start();
if(isset($_SESSION['username'])){	
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="">

	<tr>
		<td width="528" height="14" valign="top" class="error" style="padding-left:10px;">
        
        <a href="maincontent.php">Home</a></td>
	</tr>
    
       <tr> 
       <td width="528" height="14" valign="top" style="padding-left:10px;">
       
        <h2 class="trigger">Manage Category</h2>
<div class="toggle_container">
	<div class="block">
		<h3><a href="addCategory.php">Add Category</a></h3>
       <h3> <a href="viewCategory.php">View Categories</a></h3>
       
		<!--Content-->
	</div>
</div>
</td>
        </tr>
		
	
    <tr> 
       <td width="528" height="14" valign="top" class="error" style="padding-left:10px;">
       
           <h2 class="trigger">Manage Products</h2>
<div class="toggle_container">
	<div class="block">
		<h3><a href="addProduct.php">Add Products</a></h3>
       <h3> <a href="viewProducts.php">View Products</a></h3>
       
		<!--Content-->
	</div>
</div>
</td>
</tr>

    	<!--<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="addCategory.php">Add Category</a></td>
	</tr>
    <tr>
		<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="viewCategory.php">View Categories</a></td>
	</tr>-->
    
    <!--<tr>
      <td width="528" height="19" valign="top" class="error" style="padding-left:10px;"><a href="addProduct.php">Add Products</a></td>
    </tr>
    <tr>
		<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="viewProducts.php">View Products</a></td>
	</tr>-->
  
	<tr>
		 <td height="14" valign="top" style="padding-left:10px;" class="error"><a href="logout.php">Logout</a> </td>
	</tr>
	
	<tr>
		 <td height="37" colspan="3" valign="top">&nbsp;</td>
	</tr>
</table>
<?php
}
?>
