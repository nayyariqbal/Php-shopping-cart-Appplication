<?php 
error_reporting(~E_NOTICE);   
require_once("../datastore.php");
$error_msg = "";
$cid = "";
$prodsql = "SELECT * FROM books order by isbn asc";
$prodres = mysql_query($prodsql);
$numrows = mysql_num_rows($prodres);
$isbn = $_GET['isbn'];
echo"value of isbn=".$isbn;
	if($numrows == 0)
	{
		$error_msg= "&nbsp;No Books Found";
	}
	else{
				echo "<select name=\"Pro\" id=\"Pro\" onChange=\"showCategory(this.value)\">";
				echo "<option value=\"null\">Select....</option>";
		while($prodrow = mysql_fetch_assoc($prodres))
			{
				
								echo "<option value=\"".$prodrow['id']."\">".$prodrow['name']."</option>";
				
			} 
				echo "</select>";
	}
?>
                                    
		           