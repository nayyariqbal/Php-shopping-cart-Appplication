<?php 
 error_reporting(~E_NOTICE);  
//Class object creation
 require_once("../datastore.php");
  //Step 0 - include pagination class
 require_once("../classes/Pagination.php");
 
 /* Step 1 Assign Basic Variables ****/	
	$page_limit = 2;
	$total = 0;	
	$paging = "";
	$max_pages = 10;
	
//Step 2 get total records. 
 	$cntrs    = mysql_query("SELECT count(*) from books"); 
 	$totalrow = mysql_fetch_row($cntrs);	
 	$total  =  $totalrow[0];echo $total;

//Tell the page name 
 	$_pageurl = "viewProducts.php";

 //Step 3 Create class object	
	$paginate = new Paginate($page_limit, $total, $_pageurl, $max_pages);
	$paging = $paginate->displayTable();
	$page = $paginate->currentPage;
	$paginate->start = $paginate->start -1;
    
	
	
	$error_msg = "";
    if($flag==1){
 	$view_msg = "Book deleted sucessfully!!!!";
 
 }elseif($flag ==2){
    $view_msg = "Book edited sucessfully!!!!";
 }


 $prodsql = "SELECT a.id as cat_id,a.name as cat_name, b.id as prod_id, b.title as book_title, b.description as prod_desc,"
           ." b.price as prod_price, b.year as pub_year ,"." b.b_copies as book_copies , b.image as prod_img"
		   ." FROM categories a INNER JOIN books b"
		   ." WHERE a.id = b.cat_id ". $whrstr ."LIMIT $paginate->start, $paginate->limit";

 echo $prodsql;
$prodres = mysql_query($prodsql);
$numrows = mysql_num_rows($prodres); //echo $numrows;
if($numrows == 0)
{
$error_msg= "&nbsp;No Products Found";
}
else
?>
<html>
<head>
<title>Administration Area</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
		  <td class="logo"> Administration Area</td>
	  </tr>
		
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="193" valign="top" id="leftnav"><?php include("leftmenu.php");?></td>
			        <td class="maincontent_bak" align="center" valign="top">
                    
                    <table class="text_color" align="center" width="100%" >
                  
                    <tr><td colspan="5" align="center"><h4>View Products</h4></td></tr>
                    <tr><td colspan="5" align="right"><!--<a href="addCategory.php">Add new Category</a>--></td></tr>
                    <tr><td colspan="5" align="center"><?php if($error_msg){?><div align="center" style="background-color:#CCCCCC; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $error_msg; }?></div></td></tr>
                    <tr>
                      <td colspan="5" align="center">&nbsp;</td>
                    </tr>
                    <tr><td colspan="5" align="left">&nbsp;</td></tr>
                    
                  <tr>
                    <th width="16%" align="left">Category</th>
                    <th width="22%" align="left">Product Image</th>
                    <th width="20%" align="left">Product Name</th>
                    <th width="20%" align="left">Product Price</th>
                    
                            <th width="20%" align="left">Product Year</th>       
                             <th width="20%" align="left">Product Copies</th>
                    <th width="20%" align="left">Product Description</th>                    
                  </tr>
                   
               <?php 			   
			   while($prodrow = mysql_fetch_array($prodres))
				{
			    ?>    
                  <tr>                    
                    <td><?php echo $prodrow['cat_name']; ?></td>
                    <td><?php echo "<img src=\"../Products/".$prodrow['prod_img']."\""; ?></td>
                    <td><?php echo $prodrow['book_title']; ?></td>
                    <td><?php echo $prodrow['prod_price']; ?></td>
              <td><?php echo $prodrow['pub_year']; ?></td>
              
              <td><?php echo $prodrow['book_copies']; ?></td>      
                    
                    <td><?php echo $prodrow['prod_desc']; ?></td>
                      <td><a href="editProduct.php?cid=<?php echo $prodrow['cat_id'];?>&pid=<?php echo $prodrow['prod_id'];?>">Edit</a> | <a href="deleteProduct.php?pid=<?php echo $prodrow['prod_id']; ?>" onClick="return confirm('This action will delete this product?\n Are you sure to continue?');">Delete</a></td>
                  </tr>
                  
                  <?php } ?>
                                    
		           </table>             
                    
                    </td>
			    </tr>
               
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
</body>
</html>
