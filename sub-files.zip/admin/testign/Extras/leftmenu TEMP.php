<link rel="stylesheet" type="text/css" href="styles/admin.css" />
<script src="js/jquery-1.5.1.js"></script>  

<script>
$(document).ready(function(){


	$(".toggle_container1").hide(); 
	$(".toggle_container2").hide(); 
	
	$("h2.trigger1").click(function(){
		$(".toggle_container1").slideToggle("slow");
		
	});

$("h2.trigger2").click(function(){
		$(".toggle_container2").slideToggle("slow");
		
	});
});

      
    
     
</script>


<?php  
error_reporting(~E_NOTICE);
session_start();
if(isset($_SESSION['username'])){	
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="">

	<tr>
		<td width="528" height="14" valign="top" class="error" style="padding-left:10px;">
        
        <a href="maincontent.php">Home</a></td>
	</tr>
    
       <tr> 
       <td width="528" height="14" valign="top" style="padding-left:10px;">
       
        <h2 class="trigger1">Manage Category</h2>
<div class="toggle_container1">
	
		<h3><a href="addCategory.php">Add Category</a></h3>
       <h3> <a href="viewCategory.php">View Categories</a></h3>
       
		<!--Content-->
	
</div>
</td>
        </tr>
		
	
    <tr> 
       <td width="528" height="14" valign="top" class="error" style="padding-left:10px;">
       
           <h2 class="trigger2">Manage Products</h2>
<div class="toggle_container2">
	
		<h3><a href="addProduct.php">Add Products</a></h3>
       <h3> <a href="viewProducts.php">View Products</a></h3>
       
		<!--Content-->
	
</div>
</td>
</tr>

    	<!--<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="addCategory.php">Add Category</a></td>
	</tr>
    <tr>
		<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="viewCategory.php">View Categories</a></td>
	</tr>-->
    
    <!--<tr>
      <td width="528" height="19" valign="top" class="error" style="padding-left:10px;"><a href="addProduct.php">Add Products</a></td>
    </tr>
    <tr>
		<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="viewProducts.php">View Products</a></td>
	</tr>-->
  
	<tr>
		 <td height="14" valign="top" style="padding-left:10px;" class="error"><a href="logout.php">Logout</a> </td>
	</tr>
	
	<tr>
		 <td height="37" colspan="3" valign="top">&nbsp;</td>
	</tr>
</table>
<?php
}
?>
