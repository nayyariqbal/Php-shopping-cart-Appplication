<style>
 #menu {
        font-family:verdana;
        font-size:12px;
        position:relative;
        margin:0 auto;
        width:200px;
    }
     
    #menu ul {
        /* remove list style */
        list-style:none;
        padding:0;
        margin:0;  
         
        /* set the layer position */
        position:relative;
        z-index:5;
    }
     
        #menu li {
            /* set the styles */
          
            padding:5px;
            margin:2px;
            cursor:pointer;
        }
         
        #menu li.hover {
            /* on hover, change it to this image */
            background-image:url(bg_hover.gif) !important;
        }
         
        #menu li a {
            text-decoration:none;  
            color:#888;
        }
     
     
    #menu .block {
        /* allow javascript to move the block */
        position:absolute;
        top:0;
         
        /* set the left position */
        left:150px;
         
        /* display above the #menu */
        z-index:10;
         
        /* the image and the size */
        background:transparent url(arrow.png) no-repeat top right;
        width:39px;
        padding:4px;
        cursor:pointer;
    }
     
    /* fast png fix */
    * html .png{
        position:relative;
        behavior: expression((this.runtimeStyle.behavior="none")&&(this.pngSet?this.pngSet=true:(this.nodeName == "IMG" && this.src.toLowerCase().indexOf('.png')>-1?(this.runtimeStyle.backgroundImage = "none",
this.runtimeStyle.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + this.src + "', sizingMethod='image')",
this.src = "transparent.gif"):(this.origBg = this.origBg? this.origBg :this.currentStyle.backgroundImage.toString().replace('url("','').replace('")',''),
this.runtimeStyle.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + this.origBg + "', sizingMethod='crop')",
this.runtimeStyle.backgroundImage = "none")),this.pngSet=true));
    }
	</style>
<script src="js/jquery-1.5.1.js"></script>  

<script>
$(document).ready(function () {
 
    //Set the height of the block
    $('#menu .block').height($('#menu li').height());
 
    //go to the default selected item
    topval = $('#menu .selected').position()['top'];
    $('#menu .block').stop().animate({top: topval}, {easing: '', duration:500});
 
    $('#menu li').hover(
         
        function() {
             
            //get the top position
            topval = $(this).position()['top'];
             
            //animate the block
            //you can add easing to it
            $('#menu .block').stop().animate({top: topval}, {easing: '', duration:500});
             
            //add the hover effect to menu item
            $(this).addClass('hover'); 
        },
         
        function() {       
            //remove the hover effect
            $(this).removeClass('hover');  
        }
    );
 
});


</script>
<?php  
error_reporting(~E_NOTICE);
session_start();
if(isset($_SESSION['username'])){	
?>

<div id="menu">
    <ul>
        <li><a href="#">Item 01</a></li>
        <li><a href="#">Item 02</a></li>
        <li><a href="#">Item 03</a></li>   
        <li><a href="#">Item 04</a></li>
        <li><a href="#">Item 05</a></li>
        <li><a href="#">Item 05</a></li>
    </ul>
    <div class="block png"></div>
</div>
<!--
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="">

	<tr>
		<td width="528" height="14" valign="top" class="error" style="padding-left:10px;">
        
        <h2 class="trigger"><a href="maincontent.php">Home</a></h2></td>
	</tr>
    
       <tr> 
       <td width="528" height="14" valign="top" style="padding-left:10px;">
       
        <h2 class="trigger">Manage Category</h2>
<div class="toggle_container">
	<div class="block">
		<h3><a href="addCategory.php">Add Category</a></h3>
       <h3> <a href="viewCategory.php">View Categories</a></h3>
       
		<!--Content-->
	<!--</div>
</div>
</td>
        </tr>
		
	
    <tr> 
       <td width="528" height="14" valign="top" class="error" style="padding-left:10px;">
       
           <h2 class="trigger">Manage Products</h2>
<div class="toggle_container">
	<div class="block">
		<h3><a href="addProduct.php">Add Products</a></h3>
       <h3> <a href="viewProducts.php">View Products</a></h3>
       
		<!--Content-->
	</div>
</div>
</td>
</tr>-->

    	<!--<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="addCategory.php">Add Category</a></td>
	</tr>
    <tr>
		<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="viewCategory.php">View Categories</a></td>
	</tr>-->
    
    <!--<tr>
      <td width="528" height="19" valign="top" class="error" style="padding-left:10px;"><a href="addProduct.php">Add Products</a></td>
    </tr>
    <tr>
		<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="viewProducts.php">View Products</a></td>
	</tr>-->
  
	<!--<tr>
		 <td height="19" valign="top" style="padding-left:10px;" class="error"><h2 class="trigger"><a href="logout.php">Logout</a> </h2></td>
	</tr>
	
	<tr>
		 <td height="37" colspan="3" valign="top">&nbsp;</td>
	</tr>
</table>-->
<?php
}
?>
