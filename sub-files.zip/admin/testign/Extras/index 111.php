<?php
 session_start();
 error_reporting(~E_NOTICE);
 require_once('../datastore.php');   // calling datastore.php to this page
 $error_msg = "";
 $username = "";
 $password = "";
 $remember = "";  // initialling all these with null.
 
 if($_POST['sub']){    // use this $_post[sub] so that processing start after the submitting of form. here 'sub' is the name of submit button.
 
 	//get data
 	$username = strtolower($_POST['username']);  
	$password = $_POST['password'];
	
	
	$remember = $_POST['remember'];  // it sets the value of $_POST['remember'] to 0 or 1 in $remember.
	
	
	//validate
	if(!$username){ // means if username is not entered in field
	
	   $error_msg ="&nbsp;Username cannot be left blank.<br>";
	}
	
	if(!$password){
	   $error_msg .="&nbsp;Password cannot be left blank.<br>";
	
	}
	
	if(!$error_msg){ // means if there is no error message i.e, no error return from username and password fields.
	 //validate from db
	 
			 echo $sql = "select * from admins where username = \"$username\" and password = \"$password\"";  // here $username means username entered from form.
			 
			 $rs = mysql_query($sql); // it executes the above query
			 
					 if(mysql_num_rows($rs) > 0){ // if records greater than zero exists i.e, if any records match with the query.
				  
						  ///Rememebr Cookie
						  if($remember ==1){  // if user select(or checked) remeber me than this statement will be true.
							setcookie("username",$username,time()+86400); // username means field variable in form , $usename measns username value entered by user in that form , time() means the time calculated in unix seconds since 1970 plus 86400(seconds in that day) means unix seconds in a day.
							setcookie("password",$password,time()+86400);
						  }else{
						  
							setcookie("username",$username,time()-172800); // if remember me field is unchecked than unix time stamp is minus by ,for example, unix seconds of two days i.e time is set to two days before that day.
							// we do this to delete the cookie as there is no other way of deleting cookie.
							setcookie("password",$password,time()-172800);					  
						  }
						  
					  ///					
						$row = mysql_fetch_row($rs);  // The mysql_fetch_row() function returns a row from a recordset(here rs are records) as a numeric array.
						$id = $row[0];    // $row[0] contains first field or attribute(here id) of the record.
						$username = $row[1]; // $row[0] contains second field or attribute(here username) of the record.
						$_SESSION['username'] = $username; // we assign(or store) the $username to the session variable of username.
						$_SESSION['id'] =  $id; // here we assign the $id(which we get fromm databae) to the session variable of id.
						
						header("Location: maincontent.php");  // header redirects to the location given in the brackets(here maincontent.php)
						exit;
						
					  
					 
					 }else{
					 
						  $error_msg = "&nbsp;&nbsp;Username / Passwrod Invalid";	 // else display the error message at that page.
					 
					 }	
					 			
			}		
			
} //end of post
		 
		 
		 
if($_COOKIE['username'] && $_COOKIE['password']){ // if cookie of username and password exists
				
	$username = $_COOKIE['username']; // assign the cookie username value to $username for further processing.
	$password = $_COOKIE['password'];		 
 }
 
 
?>
<html>
<head>
<title>Administration Area</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
			<td class="logo">
				Administration Area</td>
		</tr>
		<tr>
			<td class="topnav" align="left">&nbsp;</td>
		</tr>
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="180px" valign="top" id="leftnav"><?php include("leftmenu.php");?></td>
			        <td valign="top" align="center">
                    <form name="form1" action="index.php" method="post">
                    <table align="center" width="56%" >
                  
                    <tr><td colspan="2" align="center"><h4>Login</h4></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    <tr><td colspan="2" align="center"><?php if($error_msg){?><div align="center" style="background-color:#CCCCCC; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $error_msg; }?></div></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    
                    <tr>
                    <td width="20%">Username</td>
                    
                    <td width="80%"><input type="text" name="username" value="<?php echo $username; ?>" /></td>
                    
                    </tr>
                    
                    <tr>
                    <td>Password</td>
                    
                    <td><input type="password" name="password" value="<?php echo $password; ?>" /> </td>
                    
                    </tr>
                    <tr>
                    <td></td>
                    
                    <td><input type="checkbox" name="remember" value="1" /> Remember Me</td>
                    
                    </tr>
                    
                    <tr>
                    <td><input type="submit" name="sub" value="Login" class="button"/></td>
                    
                    <td></td>
                    
                    </tr>
                    
                    </table>
                    
                    </form>
                    
                    </td>
			    </tr>
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
    <!--<div style="background-color:#003399; width:200px; height:100px; color:#FFFFFF">Div here</div>-->
</body>
</html>