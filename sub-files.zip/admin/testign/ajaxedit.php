
 <?php
 error_reporting(~E_NOTICE);
 
 //Class object creation
 require_once("../classes/Product.php");
 require_once("../datastore.php");
 
 $prod = new Product();
 
 $cid = intval($_GET['cid']);
 $pid = intval($_GET['pid']);
 $error_msg = "";
 $dir = "../Products/";
 if($_POST['sub']){
   
   $pName = trim($_POST['pName']);
   $pDesc = trim($_POST['pDesc']);
   $pPrice = trim($_POST['pPrice']);
    $pYear = trim($_POST['pYear']);
    $pCopies = trim($_POST['pCopies']);
	
   $cat_id    = ($_POST['cid']);
   $prod_id    = ($_POST['pid']);
   $existingImg = trim($_POST['existingImg']);
   //Validation
   echo $cat_id;
   if((!$pName)||(!$pDesc)||(!$pPrice)){
     $error_msg  = "&nbsp;All Fields are Mandatory.";
   }
      
   
   if(!$error_msg){
     //Calling setter function
	 $prod->setpName($pName);	 
	 $prod->setpPrice($pPrice);
	 $prod->setpYear($pYear);
	 $prod->setpCopies($pCopies);
	 $prod->setpDesc($pDesc);

	 
	 $prod->setCID($cat_id);
	 $prod->setPID($prod_id);
	 
    if(is_uploaded_file($_FILES['pImg']['tmp_name'])){
	 		
			$filename = $_FILES['pImg']['name'];
			
			if(move_uploaded_file($_FILES['pImg']['tmp_name'],$dir.$filename)){
			 	$prod->setpImage($filename);
			}else{
				echo "File not uploaded";
				
			}
	 }else{
	 	$prod->setpImage($existingImg);
	 
	  }	  
	  
	  //Datbase insertion code here
	  $pname  = $prod->getpName();
	  $pimg   = $prod->getpImage();
	  $pprice = $prod->getpPrice();
	  $pyear =  $prod->getpYear();
	  $pcopies =$prod->getpCopies();
	  $pdesc  = $prod->getpDesc();	  
	  $cid    = $prod->getCID();
	  $pid    = $prod->getPID();
	  
	 $sql = "UPDATE books SET cat_id = \"$cid\",title = \"$pname\" ,description = \"$pdesc\" ,image = \"$pimg\",price = \"$pprice\" ,year = \"$pyear\" ,b_copies = \"$pcopies\" WHERE isbn = $pid";
	 
	 echo  $sql;
	 if(mysql_query($sql)){
	 
	 	header("Location: viewProducts.php?flag=2");
		exit;
		
	 
	 }else{
	 
	 echo "error  ";
	 }
   }
 }
 ?>
