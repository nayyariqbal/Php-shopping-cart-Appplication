<?php  
session_start();
if(isset($_SESSION['username'])){	
?>
<html>
<head>
<title>Administration Area</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
		  <td class="logo"> Administration Area
          
	</td>
            
           			           
            
            </tr>
		
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="180px" valign="top" id="leftnav"><?php include("leftmenu.php");?></td>
			      
                                       
                                        
                                          <td class="maincontent_bak" valign="top" align="center">
                   
                    <h1 >Welcome Admin</h1>
                    
<!---Begin--Script for Clock---->

           <script src="http://24timezones.com/js/swfobject.js" language="javascript"></script>
<script src="http://24timezones.com/timescript/maindata.js.php?city=358430" language="javascript"></script>
<table><tr><td><div id="testing"><div id="flash_container_tt4e212f9811051"></div></div><script type="text/javascript">
	var flashMap = new SWFObject("http://24timezones.com/timescript/clock_final.swf", "main", "125", "125", "7.0.22", "#FFFFFF", true)
	flashMap.addParam("movie",      "http://24timezones.com/timescript/clock_final.swf");
	flashMap.addParam("quality",    "high");
	flashMap.addParam("wmode",    "transparent");
	flashMap.addParam("flashvars",  "color=00CC00&logo=1&city=358430");
	flashMap.write("flash_container_tt4e212f9811051");
</script></td></tr><tr><td style="text-align: center; font-weight: bold"><a href="http://24timezones.com/world_directory/time_in_islamabad.php" target="_blank" style="text-decoration: none" title="local current time in Islamabad"></a></td></tr></table>

<!---End--Script for Clock---->
             
                                        <img src="layout/login/login.png" align="right"/></td>
			    </tr>
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
</body>
</html>
<?php } 
else
{
header("Location: index.php");	
}
?>