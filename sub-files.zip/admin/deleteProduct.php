<?php

try
{

 require_once("../datastore.php");
 $pid = intval($_GET['pid']);
 //echo $pid;
 if($pid >0){
    mysql_query("DELETE from books WHERE isbn = $pid");
    header("Location: viewProducts.php?flag=1");
	exit;
	
 }



?>

<?php } catch(Exception $e)
{
	echo "There is a problem in opening this page.";
}?>