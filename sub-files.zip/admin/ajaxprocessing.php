<html>
<head>
<title>Administration Area</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
</head>
</html>

<?php
error_reporting(~E_NOTICE);  
 session_start();  
  if(isset($_SESSION['username'])){	
 
 //Class object creation
 require_once("../datastore.php");
 require_once("getCategoryList.php");


  //Step 0 - include pagination class
 require_once("../classes/Pagination.php");
 
 /* Step 1 Assign Basic Variables ****/	
	$page_limit = 1;
	$total = 0;	
	$paging = "";
	$max_pages = 10;
	
	 $cid = $_GET['cid']; 
	 
	 if($cid==0)
  {
	  $cntrs    = mysql_query("SELECT count(*) from books "); 
 	$totalrow = mysql_fetch_row($cntrs);
  }
  else{
  
//Step 2 get total records. 

 	$cntrs    = mysql_query("SELECT count(*) from books WHERE cat_id=$cid"); 
 	$totalrow = mysql_fetch_row($cntrs);	
  }
 	$total  =  $totalrow[0];
/*echo $total;*/

//Tell the page name 
 	/*$_pageurl = "ajaxprocessing.php";*/
 $_pageurl = "viewProducts.php";
	
 //Step 3 Create class object	
	$paginate = new Paginate($page_limit, $total, $_pageurl, $max_pages);
	$paging1 = $paginate->displayTable();
	$page = $paginate->currentPage;
	$paginate->start = $paginate->start -1;
    
 

  
 
  if($cid==0)
  {
	   $prodsql = "SELECT a.id as cat_id,a.name as cat_name, b.isbn as prod_id, b.title as book_title, b.description as prod_desc,"
           ." b.price as prod_price, b.year as pub_year ,"." b.b_copies as book_copies ,b.image as prod_img"
		   ." FROM categories a INNER JOIN books b"
		   ." WHERE a.id = b.cat_id ". $whrstr ."LIMIT $paginate->start, $paginate->limit";
  }
  else
  {
 $prodsql = "SELECT a.id as cat_id,a.name as cat_name, b.isbn as prod_id, b.title as book_title, b.description as prod_desc,"
           ." b.price as prod_price, b.year as pub_year ,"." b.b_copies as book_copies ,b.image as prod_img"
		   ." FROM categories a INNER JOIN books b" 
		   ." WHERE (a.id = b.cat_id AND b.cat_id=$cid)". $whrstr ."LIMIT $paginate->start, $paginate->limit";
		  /* echo $prodsql;*/
  }
$prodres = mysql_query($prodsql);
$numrow = mysql_num_rows($prodres); //echo $numrow;
echo "<table border=\"0\" width=\"100%\">";

echo "<tr>";
echo "<th width='11%' align='left'>Category</th>";
echo "<th width='11%' align='left'>Book Image</th>";
echo "<th width='11%' align='left'>Book Name</th>";
echo "<th width='11%' align='left'>Book Price</th>";
echo "";
echo "<th width='11%' align='left'>Publishing Year</th>";
echo "<th width='11%' align='left'>Book Copies</th>";
echo "<th width='11%' align='left'>Book Desc</th>";
echo "<th width='12%' align='left'>Actions</th>";






while($prodrow = mysql_fetch_array($prodres))
{
	?>
		
	     <tr>                    
                    <td><?php echo $prodrow['cat_name']; ?></td>
                    <td><?php echo "<img src=\"../Products/".$prodrow['prod_img']."\">"; ?></td>
                    <td><?php echo $prodrow['book_title']; ?></td>
                    <td><?php echo "\$".$prodrow['prod_price']; ?></td>
                    
                    <td><?php echo $prodrow['pub_year']; ?></td>
              
              <td><?php echo $prodrow['book_copies']; ?></td>
              
                    <td><?php echo $prodrow['prod_desc'];?></td>
                    
                   <td colspan="6"><a href="editProduct.php?cid=<?php echo $prodrow['cat_id'];?>&pid=<?php echo $prodrow['prod_id'];?>"><img src="layout/edit_icon.jpg" width="33" height="33" align="baseline"></a> <a href="deleteProduct.php?pid=<?php echo $prodrow['prod_id']; ?>" onClick="return confirm('This action will delete this product?\n Are you sure to continue?');"><img src="layout/psd-delete-icon.jpg" width="26" height="34"></a></td>
                 
</tr> 
	<?php } ?>

 <tr>
                    <td class="pagination" colspan="6" align="center" ><?php echo $paging1; ?></td>
                    </tr>

</table>

<?php } 
else
{
header("Location: index.php");	
}
?>