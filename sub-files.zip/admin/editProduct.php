<?php
try

{
error_reporting(~E_NOTICE);
 session_start();
 if(isset($_SESSION['username'])){	

 
 //Class object creation
 require_once("../classes/Product.php");
 require_once("../datastore.php");
 
 $prod = new Product();
 
 $cid = intval($_GET['cid']);
 $pid = intval($_GET['pid']);
 $error_msg = "";
 $dir = "../Products/";
 if($_POST['sub']){
   
   $pName = trim($_POST['pName']);
   $pDesc = trim($_POST['pDesc']);
   $pPrice = trim($_POST['pPrice']);
    $pYear = trim($_POST['pYear']);
    $pCopies = trim($_POST['pCopies']);
	
   $cat_id    = ($_POST['cid']);
   $prod_id    = ($_POST['pid']);
   $existingImg = trim($_POST['existingImg']);
   //Validation
  // echo $cat_id;
   if((!$pName)||(!$pDesc)||(!$pPrice)){
     $error_msg  = "&nbsp;All Fields are Mandatory.";
   }
      
   
   if(!$error_msg){
     //Calling setter function
	 $prod->setpName($pName);	 
	 $prod->setpPrice($pPrice);
	  $prod->setpYear($pYear);
	 $prod->setpCopies($pCopies);
	 $prod->setpDesc($pDesc);
	 $prod->setCID($cat_id);
	 $prod->setPID($prod_id);
	 
    if(is_uploaded_file($_FILES['pImg']['tmp_name'])){
	 		
			$filename = $_FILES['pImg']['name'];
			
			if(move_uploaded_file($_FILES['pImg']['tmp_name'],$dir.$filename)){
			 	$prod->setpImage($filename);
			}else{
				echo "File not uploaded";
				
			}
	 }else{
	 	$prod->setpImage($existingImg);
	 
	  }	  
	  
	  //Datbase insertion code here
	  $pname  = $prod->getpName();
	  $pimg   = $prod->getpImage();
	  $pprice = $prod->getpPrice();
	  $pyear =  $prod->getpYear();
	  $pcopies =$prod->getpCopies();
	  $pdesc  = $prod->getpDesc();	  
	  $cid    = $prod->getCID();
	  $pid    = $prod->getPID();
	  
	 $sql = "UPDATE books SET cat_id = \"$cid\",title = \"$pname\" ,description = \"$pdesc\" ,image = \"$pimg\",price = \"$pprice\" ,year = \"$pyear\" ,b_copies = \"$pcopies\" WHERE isbn = $pid";
	 
	 echo  $sql;
	 if(mysql_query($sql)){
	 
	 	header("Location: viewProducts.php?flag=2");
		exit;
		
	 
	 }else{
	 
	 echo "error  ";
	 }   
   } 
 } 
//Pick existing data
 
 $select = "select * from books where isbn = $pid";
 $rs = mysql_query($select);
 $row = mysql_fetch_row($rs);
 //$id = $row[0];
  $pdbName = $row[1]; 
 $pdbImg = $row[2];
 $pdbPrice = $row[3];
 $pdbYear  = $row[4];
 $pdbCopies = $row[5];
 $pdbCatid = $row[6];
 $pdbDesc = $row[7];
// $filename = $row[2];
?>
<html>
<head>
<title>Administration Area</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
<script type="text/javascript">
function showCategory(str)
{
	
	//var DataToSend = "cid="+str; 
		if (window.XMLHttpRequest)
  			{// code for IE7+, Firefox, Chrome, Opera, Safari
  				xmlhttp=new XMLHttpRequest();
  
 
 			 }
		else
  			{// code for IE6, IE5  
  				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  				//alert("hello");
 			 }
     
     document.getElementById("my_selection").value=str;	
	xmlhttp.submit();
   

}
</script>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
			<td class="logo">
				Administration Area</td>
		</tr>
		
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="180px" valign="top" id="leftnav"><?php include("leftmenu.php");?></td>
			        <td class="maincontent_bak" valign="top" align="center">
                    <form name="form1" action="editProduct.php" method="post" enctype="multipart/form-data">
                    <table align="center" width="80%" >
                  
                    <tr><td colspan="2" align="center"><h4>Edit Book</h4></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    <tr><td colspan="2" align="center"><?php if($error_msg){?><div align="center" style="background-color:#CCCCCC; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $error_msg; }?></div></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    
                
                  <tr>
                      <td>Select Category</td>
                       
                <td><?php require("getCategoryList.php"); ?></td>
                    </tr>
                    <tr>
                    <td width="22%">Book Name</td>
                    
                    <td width="78%">&nbsp;<input type="text" name="pName" value="<?php echo $pdbName; ?>" /></td>
                    
                    </tr>
                    
                    
                    <tr>
                      <td valign="top">Book Description</td>
                      <td>    <textarea name="pDesc" cols="" rows="3" value="" ><?php echo $pdbDesc; ?></textarea></td>
                    </tr>
                    <tr>
                      <td>Book Price</td>
                      <td><input type="text" name="pPrice" value="<?php echo $pdbPrice; ?>" /></td>
                    </tr>
                    
                    <tr>
                      <td>Publishing Year</td>
                      <td><input type="text" name="pYear" value="<?php echo $pdbYear; ?>" /></td>
                    </tr>
                    
                    <tr>
                      <td>Book Copies</td>
                      <td><input type="text" name="pCopies" value="<?php echo $pdbCopies; ?>" /></td>
                    </tr>
                    <tr>
                    <td>Book image</td>
                    
                    <td><input type="file" name="pImg" />
                    <input type="text" name="cid" id="my_selection" value="<?php echo $cid; ?>" /> 
                    <input type="text" name="pid" value="<?php echo $pid; ?>" />                    
                    <input type="text" name="existingImg" value="<?php echo $pdbImg; ?>" />
                    </td>
                    
                    </tr>
                    <tr>
                      <td>Existing Image</td>
                      <td><img src="<?php echo $dir.$pdbImg; ?>" /></td>
                    </tr>
                    
                    <tr>
                    <td>&nbsp;</td>
                    
                    <td><input type="submit" name="sub" width="19" height="48" class="button"  value="Edit Product" />&nbsp;<input type="button" name="sub" class="button" value="Back" onClick="window.location = 'viewProducts.php'" /></td>
                    
                    </tr>
                    
                    </table>
                    
                    </form>
                    
                    </td>
			    </tr>
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
</body>
</html>

<?php } 
else
{
header("Location: index.php");	
}
?>

<?php } catch(Exception $e)
{
	echo "There is a problem in opening this page.";
}?>