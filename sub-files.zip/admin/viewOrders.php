<?php 
try
{
 error_reporting(~E_NOTICE); 
  session_start();  
  if(isset($_SESSION['username'])){	

 require_once("../datastore.php");


/*	$prodres = mysql_query(" SELECT a.id ,a.orderStatus, a.orderTotal, a.OrderTotalQty, a.orderDate, b.orders_id "
		   ." FROM orders a INNER JOIN customer_info b");*/
		   
			
$prodres = mysql_query("SELECT * from orders"); 
 
/* $produpd = mysql_query("UPDATE Orders SET orderStatus = 'c' WHERE id=  'Francine';"); */
 
 
 

$numrows = mysql_num_rows($prodres); //echo $numrows;
if($numrows == 0)
{
$view_msg= "&nbsp;No Books Found";
}
else
?>
<html>
<head>
<title>Administration Area</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>

<!--AJAX -->



</head>
<body>

	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
		  <td class="logo"> Administration Area</td></td>
	  </tr>
		
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="193" valign="top" id="leftnav"><?php include("leftmenu.php");?></td>
			        <td class="maincontent_bak" width="861" align="center" valign="top">
                    
                    <table align="center" width="100%" id="my_selection">
                  
                    <tr><td colspan="6" align="center"><h4>Orders</h4></td></tr>
                    <tr>
                   
                      
                    </tr>
                    <tr><td colspan="6" align="center"><?php if($view_msg){?><div align="center" style="background-color:#FC0; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $view_msg; }?></div></td></tr>
                    <tr><td colspan="6" align="center">
                   
                    </td></tr>                    
                  
                  <tr>
                    <th width="11%" align="left">Order Id</th>
                    <th width="11%" align="left">Order Status</th>
                    <th width="11%" align="left">Item Price</th>
                    <th width="11%" align="left">Item Quantity</th>
                    
                    <th width="11%" align="left">Order Date</th>       
                             
                   
                    </tr>
                   
               <?php 
			   $j = 1;
			   while($prodrow = mysql_fetch_array($prodres))
				{
				
			    ?>
              
                  <tr>                    
                    <td><?php echo $prodrow[0]; ?></td>
                    
                    <td><input type="text" name="i_status" value="<?php echo $prodrow[1];?>" size="2"/></td>
                    
                    
                    <td><?php echo $prodrow[2]; ?></td>
                    <td><?php echo $prodrow[3]; ?></td>
                    
                    <td><?php echo $prodrow[4]; ?></td>
              
               
                 
                  </tr>        
                  
                  <?php } ?>
                    
                  <tr>
                  
                    </tr>
                                    
		           </table>       
                    
                    </td>
			    </tr>
               
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
   
</body>
</html>

<?php } 
else
{
header("Location: index.php");	
}
?>

<?php } catch(Exception $e)
{
	echo "There is a problem in opening this page.";
}?>