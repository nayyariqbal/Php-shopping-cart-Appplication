-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 19, 2011 at 10:41 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nayyar`
--
CREATE DATABASE `nayyar` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `nayyar`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(14) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', 'nayyar');

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE IF NOT EXISTS `author` (
  `aud_id` int(11) NOT NULL AUTO_INCREMENT,
  `aud_fname` varchar(100) NOT NULL,
  `aud_lname` varchar(100) NOT NULL,
  `aud_address` text NOT NULL,
  PRIMARY KEY (`aud_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Author' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `author`
--


-- --------------------------------------------------------

--
-- Table structure for table `book_author`
--

CREATE TABLE IF NOT EXISTS `book_author` (
  `isbn` int(11) NOT NULL AUTO_INCREMENT,
  `aud_id` int(11) NOT NULL,
  `rating` text NOT NULL,
  PRIMARY KEY (`isbn`,`aud_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='book author' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `book_author`
--


-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `isbn` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `image` varchar(30) NOT NULL,
  `price` float NOT NULL,
  `year` int(11) NOT NULL,
  `b_copies` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL COMMENT 'Foreign Key',
  `description` text NOT NULL,
  PRIMARY KEY (`isbn`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Books Details' AUTO_INCREMENT=40 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`isbn`, `title`, `image`, `price`, `year`, `b_copies`, `cat_id`, `description`) VALUES
(17, 'Warriors', 'children books-3.gif', 500, 2010, 2, 2, 'Cat stories'),
(18, 'The Color Of Magic', 'humor book-2.gif', 400, 2008, 5, 4, 'Fun to read'),
(22, 'The Little Prince', 'children books-1.gif', 600, 2011, 2, 2, 'story of a littleboy'),
(23, 'Just Add Humour', 'humor book-1.gif', 750, 2009, 4, 4, 'Funny book'),
(24, 'One Year in Beijing', 'ART book-1.gif', 500, 2004, 6, 1, 'Visual picture of Beijing'),
(25, 'Notro Dome', 'ART book-3.gif', 650, 2002, 5, 1, 'Easy to imagin'),
(26, 'Own The Zone', 'sports book-1.gif', 550, 2007, 3, 3, 'Descriptive book'),
(27, 'The Spirit of Cricket', 'sports book-2.gif', 800, 2000, 1, 3, 'Sportsman spirit'),
(28, 'A Rome', 'ART book-4.gif', 550, 2006, 4, 1, 'Explain city with pictures'),
(30, 'Painting Better Landscapes', 'a2.gif', 650, 2010, 2, 1, 'Scenaries view'),
(31, 'Water''s Way', 'a5.gif', 700, 2011, 5, 1, 'life Along the river'),
(32, 'The Birds Photography', 'a8.gif', 600, 2011, 2, 1, 'The art of birds photography'),
(33, 'Robin Hood', '14511982.gif', 450, 2009, 3, 2, 'Adventures of famous Rohin hood'),
(34, 'Jungle Book', '16762994.gif', 700, 2011, 5, 2, 'Life in jungle'),
(35, 'The Throne Of fire', '109231540.gif', 750, 2011, 3, 2, 'Interesting book'),
(36, 'Ball Of four', 's3.gif', 500, 2009, 1, 3, 'sports review'),
(37, 'Bet On', 's6.gif', 650, 2010, 4, 3, 'Describes bets on various sports'),
(38, 'Star Wars Vs stars truk', 'h8.gif', 400, 2010, 5, 4, 'funny'),
(39, 'How to drive a tank', 'h11.gif', 800, 2011, 3, 4, 'funny tips for everyone');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `image` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `image`) VALUES
(1, 'Art', 'ART.gif'),
(2, 'Children', 'children.gif'),
(3, 'Sports', 'sports.gif'),
(4, 'Humour', 'humor-2.gif');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `cus_id` int(11) NOT NULL AUTO_INCREMENT,
  `cus_fname` varchar(100) NOT NULL,
  `cus_lname` varchar(100) NOT NULL,
  `cus_address` text NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`cus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Customer' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `customer_info`
--

CREATE TABLE IF NOT EXISTS `customer_info` (
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `zip` int(20) NOT NULL,
  `phone` varchar(200) NOT NULL,
  PRIMARY KEY (`zip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='customer_info';

--
-- Dumping data for table `customer_info`
--

INSERT INTO `customer_info` (`fname`, `lname`, `email`, `address`, `country`, `city`, `state`, `zip`, `phone`) VALUES
('hghgh', '', 'ghg', 'ghgh', 'ghg', 'hgh', 'ghgh', 0, 'hghg');

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE IF NOT EXISTS `orderitems` (
  `isbn` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL COMMENT 'Foreign Key',
  `products_id` int(11) NOT NULL COMMENT 'Foreign Key',
  `quantity` int(11) NOT NULL,
  `price` float NOT NULL,
  `total` float NOT NULL,
  PRIMARY KEY (`isbn`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`isbn`, `orders_id`, `products_id`, `quantity`, `price`, `total`) VALUES
(17, 1, 0, 1, 500, 500);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderStatus` char(1) NOT NULL,
  `orderTotal` float(9,2) NOT NULL,
  `orderTotalQty` int(11) NOT NULL,
  `orderDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Orders' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `orderStatus`, `orderTotal`, `orderTotalQty`, `orderDate`) VALUES
(1, 't', 500.00, 1, '2011-07-16 14:07:29');

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE IF NOT EXISTS `publisher` (
  `pub_id` int(11) NOT NULL AUTO_INCREMENT,
  `pub_fname` varchar(100) NOT NULL,
  `pub_lname` varchar(100) NOT NULL,
  `pub_address` text NOT NULL,
  PRIMARY KEY (`pub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Publisher' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `publisher`
--


-- --------------------------------------------------------

--
-- Table structure for table `publisher_info`
--

CREATE TABLE IF NOT EXISTS `publisher_info` (
  `p_city` varchar(200) NOT NULL,
  `p_state` varchar(200) NOT NULL,
  `p_country` varchar(200) NOT NULL,
  `p_zip` int(20) NOT NULL COMMENT 'Primary Key',
  `p_phone` varchar(200) NOT NULL,
  PRIMARY KEY (`p_zip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='publisher_info';

--
-- Dumping data for table `publisher_info`
--


-- --------------------------------------------------------

--
-- Table structure for table `shipping_info`
--

CREATE TABLE IF NOT EXISTS `shipping_info` (
  `sfname` varchar(200) NOT NULL,
  `slname` varchar(200) NOT NULL,
  `semail` varchar(200) NOT NULL,
  `saddress` text NOT NULL,
  `scountry` varchar(200) NOT NULL,
  `scity` varchar(200) NOT NULL,
  `sstate` varchar(200) NOT NULL,
  `szip` int(20) NOT NULL,
  `sphone` varchar(200) NOT NULL,
  PRIMARY KEY (`szip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='shipping Information';

--
-- Dumping data for table `shipping_info`
--

INSERT INTO `shipping_info` (`sfname`, `slname`, `semail`, `saddress`, `scountry`, `scity`, `sstate`, `szip`, `sphone`) VALUES
('hghgh', '', 'ghg', 'ghgh', 'ghgh', 'ghghgh', 'ghgh', 0, 'hghgh');
