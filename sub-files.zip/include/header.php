
<?php
require_once("classes/template.php");
$menu = new template;
$items = $menu->headerfun();
echo "<ul>";

foreach($items as $key => $page)
{
echo "<li><a href=\"$page\"> ".$key."</a></li>";	
}

echo "</ul>";
?>
