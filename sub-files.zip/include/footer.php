<?php
require_once("classes/template.php");
$menu = new template;
$items = $menu->footerfun();
echo "<ul>";
foreach($items as $key => $value)
{
echo "<li><a href=\"$value\" >".$key."</a></li>";

}
echo "</ul>";

?>