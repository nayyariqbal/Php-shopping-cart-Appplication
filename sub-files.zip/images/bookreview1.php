<?php
require_once("class.php");
$img= new template;
$images = $img->bookreview1();

 foreach($images as $smallpic => $fullpic){
	list($var) = each($images);
	
	echo "<a href=\"$fullpic\" target=\"_blank\"><img src=\"$smallpic\" /></a>";
	
	
	}

	
?>