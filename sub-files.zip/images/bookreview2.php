<?php
require_once("class.php");
$img= new template;
$images = $img->bookreview2();

 foreach($images as $smallpic => $fullpic){
	
	echo "<a href=\"$fullpic\" target=\"_blank\"><img src=\"$smallpic\" /></a>";
	
	}

	
?>