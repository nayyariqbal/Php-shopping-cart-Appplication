<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<title>Free Website Templates</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="page_header">
	<div id="page_title">
	<h1>
	<img src="images/header_logo.gif" width="25" height="26" alt="" />
	<span>Books Forever</span>
	</h1>
	</div>
    


<div id="header_search">
		<form method="post" action="http://www.freewebsitetemplates.com">
		<div>
		<h3><span>Find:</span></h3>
		<input type="text" />
		<input type="image" src="images/search_button.gif" class="submit" />
		</div>
		</form>
       
	</div>


<div id="page_menu">
<?php require("header.php");?>
	
</div>

<div id="page_wrapper">
	<!-- BEGIN :: LEFT SIDEBAR -->
	<div id="page_leftcol">
		<div class="borderbox">
		<div class="leftcol_box">
		<div id="books_search">
			<h2><span>Books Search</span></h2>
			<div class="content">
				<form method="post" action="http://www.freewebsitetemplates.com">
					<div>
					<input type="text" value="Enter Keywords......" />
					<select name="what">
					<option>Title</option>
					<option>Title 2</option>
					</select>
					<input type="image" src="img/booksearch_button.gif" class="submit" />
					</div>
				</form>
				<div class="footnote">
				<a href="http://www.freewebsitetemplates.com/fsdf">Advanced Search</a>
				</div>
			</div>
		</div>
		</div>
		</div>
		<div class="borderbox">
		<div class="leftcol_box">
		<div id="catalog">
        
        
        
        
        
        
        
        
        
        
			<h2><span>Catalog</span></h2>
			<div class="content">
				<ul>
				<li><span><a href="http://www.freewebsitetemplates.com">A</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">B</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">C</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">D</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">E</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">F</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">G</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">H</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">I</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">J</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">K</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">L</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">M</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">N</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">O</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">P</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">Q</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">R</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">S</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">T</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">U</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">V</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">W</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">X</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">Y</a></span></li>
				<li><span><a href="http://www.freewebsitetemplates.com">Z</a></span></li>
				</ul>
				<div class="footnote">
					<h4>Note:</h4>
					Search your books &amp; authors by <em>the first name</em>
				</div>
			</div>
		</div>
		</div>
		</div>
        <!--File Uploading Code Start From here-->
        
        <?php
error_reporting(~E_NOTICE);
if(isset($_POST['submit']))
{
if ((($_FILES["file"]["type"] == "image/gif"))&& ($_FILES["file"]["size"] < 5242880))
{
if ($_FILES["file"]["error"] > 0)
{
	echo "Error: " . $_FILES["file"]["error"] . "<br />";
	}
	else{
		echo "Upload: " . $_FILES["file"]["name"] . "<br />";
		echo "Type: " . $_FILES["file"]["type"] . "<br />";
		echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
		echo "Stored in: " . $_FILES["file"]["tmp_name"];
		
		echo "<br/>";
		
		if(is_uploaded_file($_FILES['file']['tmp_name'])){
			echo "File ".$_FILES['file']['name']."uploaded�successfully"."<br />";
			#echo "Displaying�contents <br />";
			readfile($_FILES['file']['tmp_name']);
			}
			else {
				echo "Possible�file�upload�attack: ";
				echo "filename'".$_FILES['file']['tmp_name']."'.";
				}
				echo "<br/>";
		if (file_exists("Product/" . $_FILES["file"]["name"])){
			echo $_FILES["file"]["name"] . " already exists. ";
			}
			else{
				move_uploaded_file($_FILES["file"]["tmp_name"],"Product/".$_FILES["file"]["name"]);
				echo "Stored in: " . "Product/" . $_FILES["file"]["name"];
				}				
		
		}
	}
	else{echo "Invalid file";} 
}
 ?>
 <form enctype="multipart/form-data" action="index.php" method="post">
            <input type="hidden" name="MAX_FILE_SIZE" value="50000" />
            <input type="file" name="file" />
            <input type="submit" name="submit" value="Send file" />
</form>
<!--File Uploading Code Ended-->
		<div id="knowmore">
			<h2><span>Know More</span></h2>
			<p>
This is a template designed by free website templates
for you
<span class="image">&nbsp;</span>
for free you can replace all the text by your own text. 
			</p>
			<div class="readmore"><a href="http://www.freewebsitetemplates.com">Read More</a></div>
		</div>
		<div class="borderbox">
		<div class="leftcol_box">
		<div id="newsletter">
			<h2><span>Newsletter Signup</span></h2>
			<div class="content">
				<form method="post" action="http://www.freewebsitetemplates.com">
					<div>
					<input type="text" value="Enter Email Here" />
					<input type="image" src="img/newsletter_button.gif" class="submit" />
					<div class="clearthis">.</div>
					</div>
				</form>
			</div>
		</div>
		</div>
		</div>
        
        
  </div>
	</div>
	<!-- //END :: LEFT SIDEBAR -->
    
    
	<!-- BEGIN :: MAIN COL -->
	<div id="page_maincol">
		<div id="maincol_top">
			<div class="sideimg">&nbsp;</div>
			<div class="content">
				<h2><span>Welcome to our site</span></h2>
				<p>
This is a template designed by free website templates for you for free you can replace all the text by your own text. This is just a place holder so you can see how the site would look like. If you're having problems editing the template please don't hesitate to ask for help on the forum. You will get help
				</p>
				<div class="readmore"><a href="http://www.freewebsitetemplates.com">Read More</a></div>
			</div>
		</div>
		<div class="borderbox">
		<div class="maincol_box">
		<div id="bestsellers">
			<h2><span>Top Bestsellers</span></h2>
			<!-- BEGIN BOOK REVIEW ONE -->
			<div class="content">
			<div class="wrapper">
				<div class="bookcover">
                
<img src="images/book01.jpg" width="65" height="100" alt="Book Cover" />
    
    
            </div>
				<p>
Steffy, a business columnist for the Houston Chronicle,first began covering British Petroleum in 2005 after the deadly explosion at their Texas City refinery.
				</p>
				<p>
His investigations reveal a corporate culture of cost-cutting initiatives that put profits ahead of workers lives
				</p>
				<div class="info">
					<div class="price">
					<h3>Price: $20.00</h3>
					</div>
					<div class="buynow">
					<a href="http://www.freewebsitetemplates.com">Buy Now</a>
					</div>
					<div class="clearthis">.</div>
				</div>
			</div>
			</div>
			<!-- //END BOOK REVIEW ONE -->
			<!-- BEGIN BOOK REVIEW TWO -->
			<div class="content">
			<div class="wrapper">
				<div class="bookcover">

<img src="images/book02.jpg" width="65" height="100" alt="Book Cover" />
                </div>
				<p>
Many people feel orphaned in their lives; however, there is a vast difference between feeling like an orphan and being orphaned.
				</p>
				<p>
Orphaned children do less well in school however, studies show that a mere 15 minutes a day of individualized caring attention.. 
				</p>
				<div class="info">
					<div class="price">
					<h3>Price: $20.00</h3>
					</div>
					<div class="buynow">
					<a href="http://www.freewebsitetemplates.com">Buy Now</a>
					</div>
					<div class="clearthis">.</div>
				</div>
			</div>
			</div>
			<!-- //END BOOK REVIEW TWO -->
			<!-- BEGIN BOOK REVIEW THREE -->
			<div class="content">
			<div class="wrapper">
				<div class="bookcover">


<img src="images/book03.jpg" width="65" height="100" alt="Book Cover" />
                </div>
				<p>
A thrilling adventure story about a Canadian family in Vientiane, Laos when the communists take over in 1975.  
				</p>
				<p>
With their American friend gone. But before they know it they are involved in a breathtaking and dangerous mission to save a Lao family
				</p>
				<div class="info">
					<div class="price">
					<h3>Price: $20.00</h3>
					</div>
					<div class="buynow">
					<a href="http://www.freewebsitetemplates.com">Buy Now</a>
					</div>
					<div class="clearthis">.</div>
				</div>
			</div>
			</div>
			<!-- //END BOOK REVIEW THREE -->
			<!-- BEGIN BOOK REVIEW FOUR -->
			<div class="content">
			<div class="wrapper">
				<div class="bookcover">
                
               <img src="images/book04.gif" width="65" height="100" alt="Book Cover" />
                </div>
				<p>
The Sixth Man is basically a biography,a business man who struglle throughout his life for success... 
 				</p>
				<p>
This is just a model so you can see how the site would look like. If you're having problems about anything,ask for help on the my email.
				</p>
				<div class="info">
					<div class="price">
					<h3>Price: $20.00</h3>
					</div>
					<div class="buynow">
					<a href="http://www.freewebsitetemplates.com">Buy Now</a>
					</div>
					<div class="clearthis">.</div>
				</div>
				<div class="clearthis">.</div>
			</div>
			</div>
			<!-- //END BOOK REVIEW FOUR -->
			<div class="clearthis">.</div>
		</div>
		</div>
		</div>
		<div class="clearthis">.</div>
	</div>
	<!-- //END :: MAIN COL -->
	<!-- BEGIN :: RIGHT SIDEBAR -->
	<div id="page_rightcol">
		<div class="borderbox">
		<div class="rightcol_box">
		<div id="latest">
			<h2><span>Latest Releases &amp; News</span></h2>
			<div class="wrapper">
				<h3>June 22nd, 2005</h3>
				<div class="thumbnail"><img src="images/news_image01.gif" width="67" height="81" alt="News" /></div>
				<p>
This is a template designed by free website templates for you for free you can replace all the text by your own text. 
				</p>
				<p>
This is just a place holder so you can see how the site would look like. If you're having problems editing the template please don't hesitate to ask for help on the forum. You will get help
				</p>
				<h3>June 22nd, 2005</h3>
				<p>
This is just a place holder so you can see how the site would look like. If you're having problems editing the template please don't hesitate to ask for help on the forum. You will get help
				</p>
				<h3>June 26th, 2005</h3>
				<p>
This is a template designed by free website templates for you for free you can replace all the text by your own text. This is just a place holder so you can see how the site would look like. 
				</p>
				<p>
If you're having problems editing the template please don't hesitate to ask for help on the forum. You will get help as soon as possible. You can also use the forum to tell us what you like or dislike and what you would like to see more. Your feedback is very important to us and we will do everything to fulfil your wishes.
				</p>
				<div class="readmore"><a href="http://www.freewebsitetemplates.com">Read More</a></div>
			</div>
		</div>
		</div>
		</div>
		<div class="clearthis">.</div>
	</div>
	<!-- //END :: RIGHT SIDEBAR -->
</div>
<div id="page_spacing">
<div id="page_footer">
		<div id="links">
<?php require("footer.php");?>
	</div>
</div>
</div>
<div id="page_credit">
<a href="http://www.freewebsitetemplates.com">Copyright information goes here</a>
</div>

</body>
</html>